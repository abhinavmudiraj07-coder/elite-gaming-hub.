ELITE GAMING HUB – ELURU WEBSITE
================================

FILES
- index.html       Home
- about.html       About
- games.html       Searchable PS5/PS4 game library
- bookings.html    30-minute and 60-minute booking request form
- contact.html     Contact details and map/social links
- styles.css       Responsive dark neon styling
- app.js           Game search, slot generation, price calculation, WhatsApp request
- assets/          Supplied logo and five supplied gaming-centre photographs

IMPORTANT CONTENT NOTES
- Prices are transcribed from the supplied four-page PDF.
- PS5 and PS4 game titles are compiled from the supplied PDF pages 1–4.
- The booking form prepares a WhatsApp request to +91 98498 32552.
- This is NOT a live reservation/availability database. Staff must confirm availability manually.
- No payment gateway or admin dashboard is included.
- The GTA 6 2-hour price (₹300) is in the price list but the current booking form offers 30- and 60-minute options only. Ask the customer before adding a 2-hour slot option.
- Game descriptions are short editorial summaries, not official publisher descriptions.
- Confirm all game titles, current availability, age ratings and commercial display permissions with the business before publishing.

LOCAL PREVIEW
Open index.html in a browser. For best testing, use a static local server or deploy to Vercel.

VERCEL DEPLOYMENT
This is a static multi-page site and needs no build command.
1. Create a GitHub repository and upload the complete contents of this folder.
2. In Vercel, choose Add New Project and import that repository.
3. Framework Preset: Other.
4. Build Command: leave blank.
5. Output Directory: leave blank / root.
6. Deploy.
The Vercel Hobby plan is generally for personal, non-commercial use. Since this is a business website, check current Vercel plan terms and use an eligible plan before commercial deployment.
